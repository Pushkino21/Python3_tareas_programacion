# -*- coding: utf-8 -*-
"""
Spyder Editor

Daniel Michell Avila Garnica.
2°A Robotica
"""

import tkinter as tk   
from tkinter import PhotoImage
"""
Los bloques de funciones aqui declarados solo
llaman al programa un archivo.py
que contiene el conversor necesario
mas que por optimización de espacio
lo he realizado para no confundirme con
tanto codigo
"""

"""Bloque funciones para longitud """

def mtopg():
    from mp import m_in
    m_in()
def intom():
    from pm import in_m
    in_m()
def cmtopg():
    from cp import cm_in
    cm_in()
def intocm():
    from pc import in_cm
    in_cm()    

"""Bloque funciones para temperatura"""

def CtoF():
    from CF import C_F
    C_F()
def FtoC():
    from FC import in_m
    in_m()
   
    
"""Bloque funciones para tiempo"""
   
def Htom():
    from HM import H_M
    H_M()
def Htos():
    from HS import H_s
    H_s()
def Mtos():
    from MS import M_S
    M_S()
    
"""Bloque funciones para Velocidad"""

def khtoMs():
    from KM import K_M
    K_M()
def khtoMis():
    from KMI import K_Mi
    K_Mi()
    
""" Bloque funciones para presion """    
def PSIBAR():
    from PB import PB
    PB()
def PSIPASC():
    from PSP import PP
    PP()
def BARPASC():
    from BP import BP
    BP()
    
"""
Bloque de widgets declarados con 
tkinter, cada frame agrupa varios widgets
que invocaran a ventanas hijas
un problema que no he logrado sortear con las ventanas hijas
es un error de traceback, heinvestigado pero no he
sacado nada en claro, he entendido que tiene que ver con
la forma en la que está diseñado python.
Dicho error aparece cuando quiero llamar de nuevo una funcion que ya cerre
"""
#crear objeto ventana
ventana = tk.Tk()

#imagen fondo ventana
fondo=PhotoImage(file="engrane.gif")
lblimg=tk.Label(ventana, image=fondo).place(x=-250,y=-100)

#geometria de la ventana
ventana.geometry('800x600')
ventana.config(bg='blue')
#Nombre de la ventana
ventana.title('Multi conversor de unidades')

"""Agregar objetos al frame Longitudes"""
framelong = tk.LabelFrame(ventana, text="Conversiones Longitudes", padx = 20, pady = 20)

lbmtoin = tk.Label(framelong, text = "Metros a Pulgadas", padx = 10, pady = 10)
lbmtoin.grid(column = 0, row = 1)

btn1 = tk.Button(framelong,text = 'Abrir', command = mtopg, padx = 10, pady = 10, activebackground = '#78d6ff')
btn1.grid(column = 1, row = 1)

lbintom = tk.Label(framelong, text = "Pulgadas a Metros", padx = 10, pady = 10)
lbintom.grid(column = 0, row = 2)

btn2 = tk.Button(framelong,text = 'Abrir', command = intom, padx = 10, pady = 10, activebackground = '#78d6ff')
btn2.grid(column = 1, row = 2)

lbcmtoin = tk.Label(framelong, text = "Centimetros a Pulgadas", padx = 10, pady = 10)
lbcmtoin.grid(column = 0, row = 3)

btn3 = tk.Button(framelong,text = 'Abrir', command = cmtopg, padx = 10, pady = 10, activebackground = '#78d6ff')
btn3.grid(column = 1, row = 3)

lbintocm = tk.Label(framelong, text = "Pulgadas a Centimetros", padx = 10, pady = 10)
lbintocm.grid(column = 0, row = 4)

btn4 = tk.Button(framelong,text = 'Abrir', command = intocm, padx = 10, pady = 10, activebackground = '#78d6ff')
btn4.grid(column = 1, row = 4)

framelong.grid(column = 1, row = 1)

"""Frame de opciones temperatura"""
frametemp = tk.LabelFrame(ventana, text="Conversiones Temperaturas", padx = 20, pady = 20)

lbCF = tk.Label(frametemp, text = "Celsius a Fahrenheit", padx = 10, pady = 10)
lbCF.grid(column = 0, row = 1)

btn5 = tk.Button(frametemp,text = 'Abrir', command = CtoF, padx = 10, pady = 10, activebackground = '#78d6ff')
btn5.grid(column = 1, row = 1)

lbFC = tk.Label(frametemp, text = "Fahrenheit a Celsius", padx = 10, pady = 10)
lbFC.grid(column = 0, row = 2)

btn6 = tk.Button(frametemp,text = 'Abrir', command = FtoC, padx = 10, pady = 10, activebackground = '#78d6ff')
btn6.grid(column = 1, row = 2)


frametemp.grid(column = 3, row = 1)

"""Frame de opciones tiempo"""

frametime = tk.LabelFrame(ventana, text="Conversiones Tiempo", padx = 20, pady = 20)

lbHM = tk.Label(frametime, text = "Horas a Minutos", padx = 10, pady = 10)
lbHM.grid(column = 0, row = 1)

btn7 = tk.Button(frametime,text = 'Abrir', command = Htom, padx = 10, pady = 10, activebackground = '#78d6ff')
btn7.grid(column = 1, row = 1)

lbHS = tk.Label(frametime, text = "Horas a Segundos", padx = 10, pady = 10)
lbHS.grid(column = 0, row = 2)

btn8 = tk.Button(frametime,text = 'Abrir', command = Htos, padx = 10, pady = 10, activebackground = '#78d6ff')
btn8.grid(column = 1, row = 2)

lbMS = tk.Label(frametime, text = "Minutos a Segundos", padx = 10, pady = 10)
lbMS.grid(column = 0, row = 3)

btn9 = tk.Button(frametime,text = 'Abrir', command = Mtos, padx = 10, pady = 10, activebackground = '#78d6ff')
btn9.grid(column = 1, row = 3)

frametime.grid(column = 2, row = 1)

"""Frame de opciones Velocidad"""
framevel = tk.LabelFrame(ventana, text="Conversiones Velocidades", padx = 20, pady = 20)

lbkm = tk.Label(framevel, text = "Kilometros hora a metros segundo", padx = 10, pady = 10)
lbkm.grid(column = 0, row = 1)

btn10 = tk.Button(framevel,text = 'Abrir', command = khtoMs, padx = 10, pady = 10, activebackground = '#78d6ff')
btn10.grid(column = 1, row = 1)

lbkmi = tk.Label(framevel, text = "Kilometros hora a millas hora", padx = 10, pady = 10)
lbkmi.grid(column = 0, row = 2)

btn11 = tk.Button(framevel,text = 'Abrir', command = khtoMis, padx = 10, pady = 10, activebackground = '#78d6ff')
btn11.grid(column = 1, row = 2)

framevel.grid(column = 1, row = 2)

"""Frame de opciones Presion"""
framepre = tk.LabelFrame(ventana, text="Conversiones Presiones", padx = 20, pady = 20)

lbpb = tk.Label(framepre, text = "PSI a Bares", padx = 10, pady = 10)
lbpb.grid(column = 0, row = 1)

btn12 = tk.Button(framepre,text = 'Abrir', command = PSIBAR, padx = 10, pady = 10, activebackground = '#78d6ff')
btn12.grid(column = 1, row = 1)

lbpp = tk.Label(framepre, text = "PSI a Pascales", padx = 10, pady = 10)
lbpp.grid(column = 0, row = 2)

btn13 = tk.Button(framepre,text = 'Abrir', command = PSIPASC, padx = 10, pady = 10, activebackground = '#78d6ff')
btn13.grid(column = 1, row = 2)

lbbp = tk.Label(framepre, text = "Bares a Pascales", padx = 10, pady = 10)
lbbp.grid(column = 0, row = 3)

btn14 = tk.Button(framepre,text = 'Abrir', command = BARPASC, padx = 10, pady = 10, activebackground = '#78d6ff')
btn14.grid(column = 1, row = 3)

framepre.grid(column = 2, row = 2)


ventana.mainloop()